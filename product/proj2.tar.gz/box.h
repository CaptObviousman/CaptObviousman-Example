#ifndef BOX_H
#define BOX_H

typedef struct bx {
    int aisle;
    int shelf;
} box;

#endif
