#ifndef TRACTOR_H
#define TRACTOR_H

void* tractorThread(void* arg);
int get20Boxes();

#endif
