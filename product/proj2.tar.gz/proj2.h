#ifndef PROJ2_H
#define PROJ2_H

char* strTime(struct timeval starttime, struct timeval endtime);

#endif
